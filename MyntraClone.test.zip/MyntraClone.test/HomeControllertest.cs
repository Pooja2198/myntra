﻿using System;
using System.Collections.Generic;
using System.Text;
using MyntraClone.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestPlatform.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyntraClone.test
{
   [TestClass]
   public class HomeControllertest
    {
       [TestMethod]
       public void IndexTest()
       {
           //arrange
           HomeController controller = new HomeController();

          //act
         var result = controller.Index();
          //assert 
         Assert.IsTrue(result is ViewResult, "Index action dosen't return value");


       }
        

    }
}
